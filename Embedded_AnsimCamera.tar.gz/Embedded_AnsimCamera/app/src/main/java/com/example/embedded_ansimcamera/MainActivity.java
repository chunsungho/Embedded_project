package com.example.embedded_ansimcamera;

import android.app.Activity;
import android.app.Notification;
import android.os.AsyncTask;
import android.os.Bundle;
import android.os.Vibrator;
import android.util.Log;
import android.view.View;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;
import java.io.*;
import java.io.BufferedReader;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.Timer;
import java.util.TimerTask;
import androidx.core.app.NotificationCompat;
import androidx.core.app.NotificationManagerCompat;

import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.content.Context;
import android.graphics.Color;
import android.os.Build;


public class MainActivity extends Activity{

    EditText e1;
    ImageView img1;
    Button sendBtn , resetBtn;
    TextView textView;
    BufferedReader in;
    String data = "data";


    public void onCreate(Bundle savedInstanceState) {
        final String TAG = "socket 통신";
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        e1 = (EditText)findViewById(R.id.et);
        sendBtn = (Button)findViewById(R.id.btn);
        resetBtn = (Button)findViewById(R.id.btn2);
        textView = (TextView)findViewById(R.id.tv);

        getWindow().addFlags(WindowManager.LayoutParams.FLAG_TURN_SCREEN_ON | WindowManager.LayoutParams.FLAG_SHOW_WHEN_LOCKED | WindowManager.LayoutParams.FLAG_DISMISS_KEYGUARD);
        final Vibrator vibrator = (Vibrator)getSystemService(Context.VIBRATOR_SERVICE);
        final Timer timer = new Timer();
        TimerTask TT = new TimerTask() {
            @Override
            public void run() {
                MessageSend2 messageSender = new MessageSend2();
                messageSender.execute(e1.getText().toString());
                data = messageSender.message2;
                if (! data.equals("hello")) {
                    data = "hello";
                    vibrator.vibrate(1000);
                    createNotification();
                    textView.setText(data);
                    timer.cancel();
                    //finish();//프로그램 종료
                }
            }
        };
        timer.schedule(TT,0,1000);//timer시작
        sendBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                System.exit(0);

            }
        });

    }

    private void createNotification() {

        NotificationCompat.Builder builder = new NotificationCompat.Builder(this, "default");

        builder.setSmallIcon(R.mipmap.asd);
        builder.setContentTitle("범죄발생!");
        builder.setContentText("지금 당장 CCTV를 확인하세요");
        builder.setDefaults(Notification.DEFAULT_SOUND);
        builder.setDefaults(Notification.DEFAULT_VIBRATE);
        builder.setColor(Color.RED);
        // 사용자가 탭을 클릭하면 자동 제거
        builder.setAutoCancel(true);
        // 알림 표시
        NotificationManager notificationManager = (NotificationManager) this.getSystemService(Context.NOTIFICATION_SERVICE);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            notificationManager.createNotificationChannel(new NotificationChannel("default", "기본 채널",
                    NotificationManager.IMPORTANCE_DEFAULT));
        }
        notificationManager.notify(1, builder.build());
    }
    private void removeNotification() {
        // Notification 제거
        NotificationManagerCompat.from(this).cancel(1);
    }
}
class MessageSend2 extends AsyncTask<String, Void, Void> {

    ServerSocket s2;
    DataOutputStream dos;
    PrintWriter pw;
    String data= "NoChangeSub";
    public static String message2 = "hello";
    String TAG = "socket 통신";
    BufferedReader in;
    InputStreamReader isr =null;
    public static Socket s;

    protected Void doInBackground(String... voids) {


        String message = voids[0];

        try {

//////////////////////////////////////s = 서버(노트북)의 주소를 입력해야합니다.///////////////////////////
            s = new Socket("121.129.63.44", 7800);
            Log.d(TAG, message2);//여기까지 hello
            Log.d(TAG, "doInBackground: 서버와 연결되었습니다.");

            in = new BufferedReader(new InputStreamReader(s.getInputStream()));
            message2 = in.readLine();
            pw = new PrintWriter(s.getOutputStream());

            pw.print(message);
            pw.close();

            Log.d(TAG, message2);//여기서부터 바뀐 문자열

            Log.d(TAG, "doInBackground: 서버로 보내는 메세지 : " + message);
            //pw.write(message2);//전송함
            //pw.print(message2);//전송함
            in.close();
            Log.d(TAG, message2);
            s.close();

        } catch (IOException e) {
            e.printStackTrace();
            Log.d(TAG, "doInBackground: 에러발생");
        }
        return null;
    }
}
