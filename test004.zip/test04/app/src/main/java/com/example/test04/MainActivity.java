package com.example.test04;
//
//import java.io.BufferedInputStream;
//import java.io.BufferedReader;
//import java.io.BufferedWriter;
//import java.io.IOException;
//import java.io.InputStream;
//import java.io.InputStreamReader;
//import java.io.OutputStreamWriter;
//import java.io.PrintWriter;
//import java.net.Socket;
//import java.net.URL;
//import java.net.URLConnection;
////import org.apache.http.util.ByteArrayBuffer;
//import android.app.Activity;
//import android.os.Bundle;
//import android.os.Handler;
//import android.util.Log;
//import android.view.View;
//import android.view.View.OnClickListener;
//import android.widget.Button;
//import android.widget.EditText;
//import android.widget.TextView;
//import android.widget.Toast;
//
//public class MainActivity extends Activity {
//
//    private String html = "";
//    private Handler mHandler;
//
//    private Socket socket;
//
//    private BufferedReader networkReader;
//    private BufferedWriter networkWriter;
//
//    private String ip = "192.168.0.4";
//    // IP
//    private int port = 8080;
//// PORT번호
//
//    @Override
//    protected void onStop() {
//        super.onStop();
//        try {
//            socket.close();
//        } catch (IOException e) {
//            e.printStackTrace();
//        }
//    }
//
//    public void onCreate(Bundle savedInstanceState) {
//        super.onCreate(savedInstanceState);
//        setContentView(R.layout.activity_main);
//        mHandler = new Handler();
//
//        try {
//            setSocket(ip, port);
//            Log.d("hello", "onCreate: 서버접속에 성공하였습니다.");
//        } catch (IOException e1) {
//            e1.printStackTrace();
//            Log.d("hello", "onCreate: err");
//        }
//
//        checkUpdate.start();
//
//        final EditText editText = (EditText) findViewById(R.id.et);
//        Button btn = (Button) findViewById(R.id.btn);
//        final TextView textView = (TextView) findViewById(R.id.tv);
//
//        btn.setOnClickListener(new OnClickListener() {
//
//            public void onClick(View v) {
//                if (editText.getText().toString() != null || !editText.getText().toString().equals("")) {
//                    PrintWriter out = new PrintWriter(networkWriter, true);
//                    String return_msg = editText.getText().toString();
//                    out.println(return_msg);
//                }
//            }
//        });
//    }
//
//    private Thread checkUpdate = new Thread() {
//
//        public void run() {
//            try {
//                String line;
//                Log.w("hello", "Start Thread");
//                while (true) {
//                    Log.w("hello", "chatting is running");
//                    line = networkReader.readLine();
//                    html = line;
//                    mHandler.post(showUpdate);
//                }
//            } catch (Exception e) {
//
//            }
//        }
//    };
//
//    private Runnable showUpdate = new Runnable() {
//
//        public void run() {
//            Toast.makeText(MainActivity.this, "Coming word: " + html, Toast.LENGTH_SHORT).show();
//        }
//
//    };
//
//    public void setSocket(String ip, int port) throws IOException {
//
//        try {
//            socket = new Socket(ip, port);
//            networkWriter = new BufferedWriter(new OutputStreamWriter(socket.getOutputStream()));
//            networkReader = new BufferedReader(new InputStreamReader(socket.getInputStream()));
//        } catch (IOException e) {
//            System.out.println(e);
//            e.printStackTrace();
//        }
//
//    }
//
//}
//


import android.app.Activity;
import android.app.Notification;
import android.os.AsyncTask;
import android.os.Bundle;
import android.os.Vibrator;
import android.util.Log;
import android.view.View;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.graphics.Bitmap;
import android.widget.TextView;
import java.io.*;
import java.io.BufferedReader;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.Timer;
import java.util.TimerTask;
import androidx.core.app.NotificationCompat;
import androidx.core.app.NotificationManagerCompat;

import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.content.Context;
import android.graphics.Color;
import android.os.Build;


public class MainActivity extends Activity{

    EditText e1;
    ImageView img1;
    Button sendBtn , resetBtn;
    TextView textView;
    BufferedReader in;
    String data = "data";


    public void onCreate(Bundle savedInstanceState) {
        final String TAG = "socket 통신";
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        e1 = (EditText)findViewById(R.id.et);
        sendBtn = (Button)findViewById(R.id.btn);
        resetBtn = (Button)findViewById(R.id.btn2);
        img1 =(ImageView)findViewById(R.id.imageView);
        textView = (TextView)findViewById(R.id.tv);

        getWindow().addFlags(WindowManager.LayoutParams.FLAG_TURN_SCREEN_ON | WindowManager.LayoutParams.FLAG_SHOW_WHEN_LOCKED | WindowManager.LayoutParams.FLAG_DISMISS_KEYGUARD);
        final Vibrator vibrator = (Vibrator)getSystemService(Context.VIBRATOR_SERVICE);
        final Timer timer = new Timer();
        TimerTask TT = new TimerTask() {
            @Override
            public void run() {
                MessageSend2 messageSender = new MessageSend2();
                Log.d(TAG, "이인태1");
                messageSender.execute(e1.getText().toString());
                Log.d(TAG, "이인태2");
                data = messageSender.message2;
                Log.d(TAG, "이인태3");
                if (! data.equals("hello")) {
                    data = "hello";
                    Log.d(TAG, "이인태4");
                    vibrator.vibrate(1000);
                    createNotification();
                    Log.d(TAG, "이인태5");
                    textView.setText(data);
                    timer.cancel();
                    //finish();//프로그램 종료
                }
            }
        };
        timer.schedule(TT,0,1000);//timer시작
        sendBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                System.exit(0);

            }
        });

    }

    private void createNotification() {

        NotificationCompat.Builder builder = new NotificationCompat.Builder(this, "default");

        builder.setSmallIcon(R.mipmap.ic_launcher);
        builder.setContentTitle("범죄발생!");
        builder.setContentText("지금 당장 CCTV를 확인하세요");
        builder.setDefaults(Notification.DEFAULT_SOUND);
        builder.setDefaults(Notification.DEFAULT_VIBRATE);
        builder.setColor(Color.RED);
        // 사용자가 탭을 클릭하면 자동 제거
        builder.setAutoCancel(true);
        // 알림 표시
        NotificationManager notificationManager = (NotificationManager) this.getSystemService(Context.NOTIFICATION_SERVICE);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            notificationManager.createNotificationChannel(new NotificationChannel("default", "기본 채널",
                    NotificationManager.IMPORTANCE_DEFAULT));
        }
        notificationManager.notify(1, builder.build());
    }
    private void removeNotification() {
        // Notification 제거
        NotificationManagerCompat.from(this).cancel(1);
    }
}
class MessageSend2 extends AsyncTask<String, Void, Void> {

    ServerSocket s2;
    DataOutputStream dos;
    PrintWriter pw;
    String data= "NoChangeSub";
    public static String message2 = "hello";
    String TAG = "socket 통신";
    BufferedReader in;
    InputStreamReader isr =null;
    public static Socket s;

    protected Void doInBackground(String... voids) {


        String message = voids[0];

        try {

            s = new Socket("192.168.0.138", 7800);
            Log.d(TAG, message2);//여기까지 hello
            Log.d(TAG, "doInBackground: 서버와 연결되었습니다.");

            in = new BufferedReader(new InputStreamReader(s.getInputStream()));
            message2 = in.readLine();
            pw = new PrintWriter(s.getOutputStream());

            pw.print(message);
            pw.close();

            Log.d(TAG, message2);//여기서부터 바뀐 문자열

            Log.d(TAG, "doInBackground: 서버로 보내는 메세지 : " + message);
            //pw.write(message2);//전송함
            //pw.print(message2);//전송함
            in.close();
            Log.d(TAG, message2);
            s.close();

        } catch (IOException e) {
            e.printStackTrace();
            Log.d(TAG, "doInBackground: 에러발생");
        }
        return null;
    }
}
