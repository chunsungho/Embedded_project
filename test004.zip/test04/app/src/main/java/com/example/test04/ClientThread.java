package com.example.test04;
import android.os.AsyncTask;
import android.util.Log;

import java.io.*;
import java.io.IOException;
import java.io.PrintWriter;
import java.net.Socket;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;

public class ClientThread extends Thread {
    Handler handler = new Handler();
    TextView textView;
    String TAG = "socket 통신";
    String input ="변화없음";
    BufferedReader in;

    public void run() {
        String host = "192.168.0.144";
        int port = 7800;

        try {
            Socket socket = new Socket(host, port);
            Log.d(TAG, "여기1");
            ObjectOutputStream outputStream = new ObjectOutputStream(socket.getOutputStream());
            Log.d(TAG, "여기2");
            outputStream.writeObject("5");
            Log.d(TAG, "여기3");
            outputStream.flush();
            Log.d(TAG, "여기4");
            Log.d("ClientThread", "보내봅니다.");
            ObjectInputStream inputStream = new ObjectInputStream(socket.getInputStream());
            Log.d(TAG, "여기5");
            Log.d(TAG, input);
            in = new BufferedReader(new InputStreamReader(socket.getInputStream()));
            while((input = in.readLine() ) != null){
                Log.d(TAG, "루프중");
            }
            in.close();
            socket.close();
            /*
            input = (String) inputStream.readObject(); // Object로 받아도 무방
            Log.d(TAG, "여기6");
            Log.d("ClientThread","받은 데이터 : "+input);

            handler.post(new Runnable() {
                @Override
                public void run() {
                    textView.setText("받은 데이터 : "+input);
                }
            });
            */

        } catch (Exception e) {
            e.printStackTrace();
            Log.d(TAG, "오류");
        }
    }
}
