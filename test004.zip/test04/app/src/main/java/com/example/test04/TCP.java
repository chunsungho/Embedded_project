package com.example.test04;

import android.util.Log;

import java.io.*;
import java.net.*;
import android.widget.TextView;

public class TCP implements Runnable{
    int ServerPort = 7800;
    final String TAG = "socket 통신";
    String ServerIp = "192.168.0.144";

    String input = "변화없음";

    @Override
    public void run(){
        try{
            Log.d(TAG, "이곳1");
            ServerSocket serverSocket = new ServerSocket(ServerPort);
            Log.d(TAG, "이곳2");
            while(true){
                Socket client = serverSocket.accept();
                Log.d(TAG, "이곳3");
                try{
                    BufferedReader in = new BufferedReader(new InputStreamReader(client.getInputStream()));
                    Log.d(TAG, "이곳4");
                    input = in.readLine();

                    Log.d(TAG, "이곳5");
                    Log.d(TAG, input);
                }catch (Exception e){
                    e.printStackTrace();
                }finally {
                    client.close();
                }
            }
        }catch (Exception e){
            e.printStackTrace();
        }
    }

}
