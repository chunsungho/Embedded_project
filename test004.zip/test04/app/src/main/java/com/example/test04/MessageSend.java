package com.example.test04;

import android.os.AsyncTask;
import android.util.Log;
import android.widget.TextView;

import java.io.BufferedInputStream;
import java.io.BufferedReader;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.io.PrintWriter;
import java.net.ServerSocket;
import java.net.Socket;
import java.lang.*;


public class MessageSend extends AsyncTask<String, Void, Void> {

    ServerSocket s2;
    DataOutputStream dos;
    PrintWriter pw;
    String data= "NoChangeSub";
    String message2 = "hello";
    String TAG = "socket 통신";
    BufferedReader in;
    InputStreamReader isr =null;
    public static Socket s;

    protected Void doInBackground(String... voids) {


        String message = voids[0];

        try {

            s = new Socket("192.168.0.144", 7800);
            Log.d(TAG, message2);//여기까지 hello
            Log.d(TAG, "doInBackground: 서버와 연결되었습니다.");

            in = new BufferedReader(new InputStreamReader(s.getInputStream()));
            message2 = in.readLine();
            pw = new PrintWriter(s.getOutputStream());

            pw.print(message);
            pw.close();

            Log.d(TAG, message2);//여기서부터 바뀐 문자열
            Log.d(TAG, "여기1");
            Log.d(TAG, "여기2");

            Log.d(TAG, "여기3");
            //Log.d(TAG, message2);
            Log.d(TAG,"여기4");
            Log.d(TAG, "doInBackground: 서버로 보내는 메세지 : " + message);
            //pw.write(message2);//전송함
            //pw.print(message2);//전송함
            //pw.close();

            Log.d(TAG, "여기5");


            Log.d(TAG, "여기6");

            //message2 = in.readLine();
            /*
            while((message2 = in.readLine() ) != null){
                Log.d(TAG, "루프중");
            }
            */

            Log.d(TAG, "여기7");
            //in.close();
            Log.d(TAG, message2);

           //s.close();

        } catch (IOException e) {
            e.printStackTrace();
            Log.d(TAG, "doInBackground: 에러발생");
        }
        return null;
    }
}
